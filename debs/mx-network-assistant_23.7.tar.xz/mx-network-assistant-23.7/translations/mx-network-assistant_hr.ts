<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <source>MX Network Assistant</source>
        <translation>MX mrežni pomoćnik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="86"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="109"/>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvori</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="219"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>IP address</source>
        <translation>IP adresa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Hardware detected</source>
        <translation>Otkriveno sklopovlje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="280"/>
        <source>Enable</source>
        <translation>Omogući</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="303"/>
        <location filename="../mainwindow.ui" line="593"/>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Re-scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="372"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="387"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Disable</source>
        <translation>Onemogući</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="419"/>
        <source>Active interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="435"/>
        <source>WiFi status</source>
        <translation>WiFi status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="457"/>
        <source>Unblocks all soft/hard blocked wireless devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="460"/>
        <source>Unblock WiFi Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="492"/>
        <source>Linux drivers</source>
        <translation>Linux upravljački programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="504"/>
        <source>Associated Linux drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="513"/>
        <source>Load Driver</source>
        <translation>Učitaj upravljački program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="576"/>
        <source>Unload Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="613"/>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>Block Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="632"/>
        <source>Windows drivers</source>
        <translation>Windows upravljački programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="638"/>
        <source>Available Windows drivers</source>
        <translation>Dostupni Windows upravljački programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="672"/>
        <source>Remove Driver</source>
        <translation>Ukloni upravljački program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Add Driver</source>
        <translation>Dodaj upravljački program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="724"/>
        <source>About NDISwrapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="736"/>
        <source>Install NDISwrapper</source>
        <translation>Instaliraj NDISwrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="747"/>
        <source>In order to use Windows drivers you need first to install NDISwrapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Uninstall NDISwrapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="795"/>
        <source>Net diagnostics</source>
        <translation>Dijagnostika mreže</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="807"/>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="813"/>
        <location filename="../mainwindow.ui" line="930"/>
        <source>Target URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <source>Packets</source>
        <translation>Paketi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="865"/>
        <location filename="../mainwindow.ui" line="985"/>
        <source>Start</source>
        <translation>Počni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="882"/>
        <location filename="../mainwindow.ui" line="1002"/>
        <source>Clear</source>
        <translation>Očisti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="896"/>
        <location filename="../mainwindow.ui" line="1016"/>
        <source>Cancel</source>
        <translation>Otkaži</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="924"/>
        <source>Traceroute</source>
        <translation>Traceroute</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="940"/>
        <source>Hops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="98"/>
        <source>IP address from router:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="99"/>
        <source>External IP address:</source>
        <translation>Vanjska IP adresa:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <location filename="../mainwindow.cpp" line="148"/>
        <source>Interface: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <location filename="../mainwindow.cpp" line="149"/>
        <source>Driver: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="136"/>
        <location filename="../mainwindow.cpp" line="150"/>
        <source>Description: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="137"/>
        <location filename="../mainwindow.cpp" line="151"/>
        <source>Product: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="137"/>
        <location filename="../mainwindow.cpp" line="152"/>
        <source>Vendor: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="138"/>
        <location filename="../mainwindow.cpp" line="153"/>
        <source>Enabled: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="206"/>
        <location filename="../mainwindow.cpp" line="220"/>
        <location filename="../mainwindow.cpp" line="234"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiraj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="208"/>
        <location filename="../mainwindow.cpp" line="222"/>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="209"/>
        <location filename="../mainwindow.cpp" line="223"/>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Copy &amp;All</source>
        <translation>Kopiraj &amp;sve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="211"/>
        <location filename="../mainwindow.cpp" line="225"/>
        <location filename="../mainwindow.cpp" line="239"/>
        <source>Ctrl+A</source>
        <translation>CTRL+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <location filename="../mainwindow.cpp" line="282"/>
        <source>Traceroute not installed</source>
        <translation>Traceroute nije instaliran</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="265"/>
        <source>Traceroute is not installed, do you want to install it now?</source>
        <translation>Traceroute nije instaliran, želite li ga instalirati sada?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="272"/>
        <source>Traceroute hasn&apos;t been installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="273"/>
        <source>Traceroute cannot be installed. This may mean you are using the LiveCD or you are unable to reach the software repository,</source>
        <translation>Traceroute se ne može instalirati. To može značiti da koristite LiveCD ili da niste u mogućnosti dohvatiti repozitorije softwarea.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="283"/>
        <source>Traceroute is not installed and no Internet connection could be detected so it cannot be installed</source>
        <translation>Traceroute nije instaliran i nema otkrivene internetske veze te ne može biti instaliran</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="290"/>
        <location filename="../mainwindow.cpp" line="329"/>
        <source>No destination host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="290"/>
        <location filename="../mainwindow.cpp" line="329"/>
        <source>Please fill in the destination host field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="452"/>
        <source>Loaded Drivers</source>
        <translation>Učitani upravljački programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="460"/>
        <source>Unloaded Drivers</source>
        <translation>Neučitani upravljački programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>Blocked Drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="492"/>
        <source>Blocked Broadcom Drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Ndiswrapper is not installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="525"/>
        <source>driver installed</source>
        <translation>upravljački program je instaliran</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="534"/>
        <source> and in use by </source>
        <translation>i koristi ga</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <source>. Alternate driver: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="612"/>
        <source>Driver removed from blocklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="612"/>
        <source>Driver removed from blocklist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="618"/>
        <source>Module blocked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="778"/>
        <source>Installation successful</source>
        <translation>Uspješna instalacija</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="780"/>
        <source>Error detected, could not compile ndiswrapper driver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="783"/>
        <source>Error detected, could not install ndiswrapper.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="795"/>
        <source>Error encountered while removing Ndiswrapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="842"/>
        <source>Unblock Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>enabled</source>
        <translation>omogućeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="877"/>
        <source>disabled</source>
        <translation>onemogućeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="880"/>
        <source>WiFi hardware switch is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="888"/>
        <source>Locate the Windows driver you want to add</source>
        <translation>Locirajte Windows upravljački program koji želite dodati</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="889"/>
        <source>Windows installation information file (*.inf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="919"/>
        <source>*.sys file not found</source>
        <translation>*.sys datoteka nije nađena</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>The *.sys files must be in the same location as the *.inf file. %1 cannot be found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>sys file reference not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="932"/>
        <source>The sys file for the given driver cannot be determined after parsing the inf file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="946"/>
        <source>Ndiswrapper driver removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="954"/>
        <source>%1 Help</source>
        <translation>%1 Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="963"/>
        <source>Could not unlock devices.
WiFi device(s) might already be unlocked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="965"/>
        <source>WiFi devices unlocked.</source>
        <translation>WiFi uređaji su otključani.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="976"/>
        <source>About %1</source>
        <translation>O programu %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="977"/>
        <source>Version: </source>
        <translation>Inačica:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="979"/>
        <source>Program for troubleshooting and configuring network for MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="981"/>
        <source>Copyright (c) MEPIS LLC and MX Linux</source>
        <translation>Autorska prava (c) MEPIS LLC and MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="982"/>
        <source>%1 License</source>
        <translation>%1 Licenca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1001"/>
        <source>Driver loaded successfully</source>
        <translation>Upravljački program je uspješno učitan</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1016"/>
        <source>Driver unloaded successfully</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="52"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="54"/>
        <source>Cancel</source>
        <translation>Otkaži</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="74"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvori</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="64"/>
        <source>Error</source>
        <translation>Greška</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="65"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="635"/>
        <source>Could not load </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="659"/>
        <source>Could not unload </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
