<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>MXDateTime</name>
    <message>
        <location filename="../datetime.ui" line="20"/>
        <location filename="../datetime.cpp" line="604"/>
        <source>MX Date &amp; Time</source>
        <translation>MX Data &amp; Hora</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="26"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="40"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="73"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="100"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="124"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Data &amp;&amp; Hora</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="192"/>
        <source>H:mm:ss</source>
        <translation>H:mm:ss</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="278"/>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>Hardware Clock</source>
        <translation>Relógio do Equipamento</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="284"/>
        <source>Hardware Clock tools</source>
        <translation>Ferramentas do Relógio do Equipamento</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="290"/>
        <source>Obtain information from the Hardware Clock and present it in the box below.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="293"/>
        <source>Read the Hardware Clock</source>
        <translation>Ler o Relógio do Equipamento</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="303"/>
        <source>Apply systematic drift corrections to the Hardware Clock.</source>
        <translation>Aplicar corecções ao desvio sistemático do Relógio do Equipamento.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="306"/>
        <source>Drift Adjust</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="329"/>
        <source>Time transfer</source>
        <translation>Transferência de tempo</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="335"/>
        <source>Immediately set the System Clock to match the current time registered by the Hardware Clock.</source>
        <translation>Definir imediatamente o Relógio do Sistema de modo a ter a mesma hora exibida no Relógio do Equipamento.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="338"/>
        <source>Hardware Clock to System Clock</source>
        <translation>Relógio do Equipamento para o Relógio do Sistema</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="348"/>
        <source>Immediately set the Hardware Clock to match the current time registered by the System Clock.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="351"/>
        <source>System Clock to Hardware Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="361"/>
        <source>Update the drift factor for the Hardware Clock when it is being set.</source>
        <translation>Actualizar o factor de desvio do Relógio do Equipamento ao definir a hora.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="364"/>
        <source>Update the drift</source>
        <translation>Actualizar o desvio</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="374"/>
        <source>Time zone for the Hardware Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="380"/>
        <source>Local time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="383"/>
        <source>Local</source>
        <translation>Local</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="390"/>
        <source>Universally Coordinated Time (or Greenwich Meridian Time)</source>
        <translation>Tempo Universal Coordenado (ou Hora do Meridiano de Greenwich)</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="393"/>
        <source>UTC</source>
        <translation>UTC</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="433"/>
        <source>Network Time</source>
        <translation>Hora da rede</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="439"/>
        <source>Move the selected item down</source>
        <translation>Mover item selecionado para baixo</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="450"/>
        <source>Move the selected item up</source>
        <translation>Mover item selecionado para cima</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="461"/>
        <source>Remove the current item from the list</source>
        <translation>Remover item atual da lista</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="472"/>
        <source>Add an item to the list</source>
        <translation>Adicionar item à lista</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="498"/>
        <source>Automatically update the System Clock with NTP servers:</source>
        <translation>Actualização automática da Hora do Sistema através de servidores NTP:</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="505"/>
        <source>Immediately update the system clock with NTP servers.</source>
        <translation>Actualização imediata do Relógio do Sistema com os servidores NTP .</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="508"/>
        <source>Update Now</source>
        <translation>Actualizar agora</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="520"/>
        <source>List of NTP servers to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="536"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="541"/>
        <source>Address</source>
        <translation>Endereço</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="546"/>
        <source>Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="270"/>
        <source>Reading...</source>
        <translation>A ler...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="284"/>
        <source>Adjusting...</source>
        <translation>A ajustar...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>System Clock</source>
        <translation>Relógio do sistema</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="309"/>
        <source>The %1 time was transferred to the %2.</source>
        <translation>A hora do %1 foi transferida para o %2.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="312"/>
        <source>The %1 time could not be transferred to the %2.</source>
        <translation>A hora do %1 não foi transferida para o %2.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="352"/>
        <source>Updating...</source>
        <translation>A actualizar...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="365"/>
        <source>The system clock was updated successfully.</source>
        <translation>O Relógio do Sistema foi actualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="367"/>
        <source>The system clock could not be updated.</source>
        <translation>O relógio do sistema não foi actualizado</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="369"/>
        <source>None of the NTP servers on the list are currently enabled.</source>
        <translation>Nenhum dos servidores NTP da lista está actualmente activado.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="603"/>
        <source>About MX Date &amp; Time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="604"/>
        <source>Version: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="605"/>
        <source>GUI program for setting the time and date in MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="607"/>
        <source>Copyright (c) MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="608"/>
        <location filename="../datetime.cpp" line="622"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="609"/>
        <source>Changelog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="610"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="636"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="654"/>
        <source>MX Date &amp; Time Help</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>