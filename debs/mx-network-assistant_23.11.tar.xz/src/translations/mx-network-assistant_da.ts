<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <source>MX Network Assistant</source>
        <translation>MX Netværksassistent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="86"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="109"/>
        <source>Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>&amp;Close</source>
        <translation>&amp;Luk</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>Alt+C</source>
        <translation>Alt+L</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="219"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>IP address</source>
        <translation>IP-adresse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Hardware detected</source>
        <translation>Hardwareregistrering</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="280"/>
        <source>Enable</source>
        <translation>Aktivér</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="303"/>
        <location filename="../mainwindow.ui" line="593"/>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Re-scan</source>
        <translation>Skan igen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="372"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="387"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Disable</source>
        <translation>Deaktivér</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="419"/>
        <source>Active interface</source>
        <translation>Aktiv grænseflade</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="435"/>
        <source>WiFi status</source>
        <translation>WiFi-status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="457"/>
        <source>Unblocks all soft/hard blocked wireless devices</source>
        <translation>Afblokerer alle blødt/hårdt blokerede trådløse enheder</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="460"/>
        <source>Unblock WiFi Devices</source>
        <translation>Afbloker WiFi-enheder</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="492"/>
        <source>Linux drivers</source>
        <translation>Linux-drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="504"/>
        <source>Associated Linux drivers</source>
        <translation>Tilknyttede Linux-drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="513"/>
        <source>Load Driver</source>
        <translation>Indlæs driver</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="576"/>
        <source>Unload Driver</source>
        <translation>Afindlæs driver</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="613"/>
        <location filename="../mainwindow.cpp" line="832"/>
        <source>Block Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="632"/>
        <source>Windows drivers</source>
        <translation>Windows-drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="638"/>
        <source>Available Windows drivers</source>
        <translation>Tilgængelige Windows-drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="672"/>
        <source>Remove Driver</source>
        <translation>Fjern driver</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Add Driver</source>
        <translation>Tilføj driver</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="724"/>
        <source>About NDISwrapper</source>
        <translation>Om NDISwrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="736"/>
        <source>Install NDISwrapper</source>
        <translation>Installer NDISwrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="747"/>
        <source>In order to use Windows drivers you need first to install NDISwrapper</source>
        <translation>For at bruge Windows-drivere, skal du først installere NDISwrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Uninstall NDISwrapper</source>
        <translation>Afinstaller NDISwrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="795"/>
        <source>Net diagnostics</source>
        <translation>Netdiagnostisk</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="807"/>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="813"/>
        <location filename="../mainwindow.ui" line="933"/>
        <source>Target URL:</source>
        <translation>Mål-URL:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <source>Packets</source>
        <translation>Pakker</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="868"/>
        <location filename="../mainwindow.ui" line="991"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="885"/>
        <location filename="../mainwindow.ui" line="1008"/>
        <source>Clear</source>
        <translation>Ryd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="899"/>
        <location filename="../mainwindow.ui" line="1022"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="927"/>
        <source>Traceroute</source>
        <translation>Traceroute</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="943"/>
        <source>Hops</source>
        <translation>Hops</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="87"/>
        <source>IP address from router:</source>
        <translation>IP-adresse fra router:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="88"/>
        <source>External IP address:</source>
        <translation>Ekstern IP-adresse:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="125"/>
        <location filename="../mainwindow.cpp" line="138"/>
        <source>Interface: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="125"/>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>Driver: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="126"/>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Description: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <location filename="../mainwindow.cpp" line="141"/>
        <source>Product: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Vendor: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="128"/>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>Enabled: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="196"/>
        <location filename="../mainwindow.cpp" line="210"/>
        <location filename="../mainwindow.cpp" line="224"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiér</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="198"/>
        <location filename="../mainwindow.cpp" line="212"/>
        <location filename="../mainwindow.cpp" line="226"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <location filename="../mainwindow.cpp" line="213"/>
        <location filename="../mainwindow.cpp" line="227"/>
        <source>Copy &amp;All</source>
        <translation>Kopiér &amp;alle</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="201"/>
        <location filename="../mainwindow.cpp" line="215"/>
        <location filename="../mainwindow.cpp" line="229"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <location filename="../mainwindow.cpp" line="278"/>
        <source>Traceroute not installed</source>
        <translation>Traceroute ikke installeret</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Traceroute is not installed, do you want to install it now?</source>
        <translation>Traceroute er ikke installeret, vil du installere den nu?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="268"/>
        <source>Traceroute hasn&apos;t been installed</source>
        <translation>Traceroute blev ikke installeret</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="269"/>
        <source>Traceroute cannot be installed. This may mean you are using the LiveCD or you are unable to reach the software repository,</source>
        <translation>Traceroute kan ikke installeres. Det kan betyde at du bruger LiveCD eller at du ikke kan nå softwarekilden,</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="279"/>
        <source>Traceroute is not installed and no Internet connection could be detected so it cannot be installed</source>
        <translation>Traceroute er ikke installeret og der kunne ikke registreres nogen internetforbindelse, så den kan ikke installeres</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>No destination host</source>
        <translation>Ingen destinationsvært</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>Please fill in the destination host field</source>
        <translation>Udfyld venligst destinationsvært-feltet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="446"/>
        <source>Loaded Drivers</source>
        <translation>Indlæste drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="455"/>
        <source>Unloaded Drivers</source>
        <translation>Afindlæste drivere</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>Blocked Drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="489"/>
        <source>Blocked Broadcom Drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="511"/>
        <source>Ndiswrapper is not installed</source>
        <translation>Ndiswrapper er ikke installeret</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="524"/>
        <source>driver installed</source>
        <translation>driver installeret</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <source> and in use by </source>
        <translation>og i brug af</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="540"/>
        <source>. Alternate driver: </source>
        <translation>. Alternativ driver: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Driver removed from blocklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Driver removed from blocklist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="610"/>
        <source>Module blocked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="762"/>
        <source>Installation successful</source>
        <translation>Installation lykkedes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="764"/>
        <source>Error detected, could not compile ndiswrapper driver.</source>
        <translation>Fejl registreret, kunne ikke kompilere ndiswrapper-driver.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="767"/>
        <source>Error detected, could not install ndiswrapper.</source>
        <translation>Fejl registreret, kunne ikke installere ndiswrapper.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="779"/>
        <source>Error encountered while removing Ndiswrapper</source>
        <translation>Fejl registreret under fjernelse af Ndiswrapper</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="829"/>
        <source>Unblock Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="861"/>
        <source>enabled</source>
        <translation>aktivér</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="864"/>
        <source>disabled</source>
        <translation>deaktivér</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="867"/>
        <source>WiFi hardware switch is off</source>
        <translation>WiFi hardwarekontakten er slukket</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>Locate the Windows driver you want to add</source>
        <translation>Find den Windows-driver du vil tilføje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="875"/>
        <source>Windows installation information file (*.inf)</source>
        <translation>Windows-installationsinformation-fil (*.inf)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="906"/>
        <source>*.sys file no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="918"/>
        <source>sys file refeot found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*.sys file not found</source>
        <translation type="vanished">*.sys-fil ikke fundet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="907"/>
        <source>The *.sys files must be in the same location as the *.inf file. %1 cannot be found</source>
        <translation>*.sys-filedrne skal være i den samme placering som *.inf-filen. Kan ikke finde %1</translation>
    </message>
    <message>
        <source>sys file reference not found</source>
        <translation type="vanished">sys-filreference ikke fundet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="919"/>
        <source>The sys file for the given driver cannot be determined after parsing the inf file</source>
        <translation>Sys-filen til den givne driver kan ikke bestemmes efter fortolkning af inf-filen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="936"/>
        <source>Ndiswrapper driver removed.</source>
        <translation>Ndiswrapper-driver fjernet.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="944"/>
        <source>%1 Help</source>
        <translation>%1-hjælp</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="956"/>
        <source>Could not unlock devices.
WiFi device(s) might already be unlocked.</source>
        <translation>Kunne ikke afblokere enheder.
WiFi-enhed(er) er måske allerede låst op.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="958"/>
        <source>WiFi devices unlocked.</source>
        <translation>WiFi-enheder låst op.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="973"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="974"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="976"/>
        <source>Program for troubleshooting and configuring network for MX Linux</source>
        <translation>Program til at fejlsøge og konfigurere netværk til MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="978"/>
        <source>Copyright (c) MEPIS LLC and MX Linux</source>
        <translation>Ophavsret (c) MEPIS LLC og MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="979"/>
        <source>%1 License</source>
        <translation>%1-licens</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1005"/>
        <source>Driver loaded successfully</source>
        <translation>Driver indlæst</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1020"/>
        <source>Driver unloaded successfully</source>
        <translation>Driver afindlæst</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation>Ændringslog</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="75"/>
        <source>&amp;Close</source>
        <translation>&amp;Luk</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="71"/>
        <location filename="../main.cpp" line="79"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="72"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="625"/>
        <source>Could not load </source>
        <translation>Kunne ikke indlæse</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>Could not unload </source>
        <translation>Kunne ikke afindlæse</translation>
    </message>
</context>
</TS>
