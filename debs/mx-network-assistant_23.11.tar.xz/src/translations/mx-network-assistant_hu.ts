<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <source>MX Network Assistant</source>
        <translation>MX hálózati segéd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="86"/>
        <source>About...</source>
        <translation>Névjegy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="109"/>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>&amp;Close</source>
        <translation>&amp;Bezárás</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="219"/>
        <source>Status</source>
        <translation>Állapot</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>IP address</source>
        <translation>IP cím</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Hardware detected</source>
        <translation>Hardver érzékelve</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="280"/>
        <source>Enable</source>
        <translation>Engedélyez</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="303"/>
        <location filename="../mainwindow.ui" line="593"/>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Re-scan</source>
        <translation>Újra ellenőrzés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="372"/>
        <source>Enabled</source>
        <translation>Engedélyezve</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Interface</source>
        <translation>Interfész</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <source>Driver</source>
        <translation>Illesztőprogram</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="387"/>
        <source>Description</source>
        <translation>Leírás</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Vendor</source>
        <translation>Gyártó</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <source>Product</source>
        <translation>Termék</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Disable</source>
        <translation>Letiltás</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="419"/>
        <source>Active interface</source>
        <translation>Aktív interfész</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="435"/>
        <source>WiFi status</source>
        <translation>WiFi állapot</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="457"/>
        <source>Unblocks all soft/hard blocked wireless devices</source>
        <translation>Feloldja a letiltott vezeték nélküli eszközöket</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="460"/>
        <source>Unblock WiFi Devices</source>
        <translation>WiFi eszközök feloldása</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="492"/>
        <source>Linux drivers</source>
        <translation>Linux illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="504"/>
        <source>Associated Linux drivers</source>
        <translation>Kapcsolódó Linux illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="513"/>
        <source>Load Driver</source>
        <translation>Illesztőprogram betöltése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="576"/>
        <source>Unload Driver</source>
        <translation>Illesztőprogram kilövése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="613"/>
        <location filename="../mainwindow.cpp" line="832"/>
        <source>Block Driver</source>
        <translation>Illesztőprogram tiltólistára helyezése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="632"/>
        <source>Windows drivers</source>
        <translation>Windows illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="638"/>
        <source>Available Windows drivers</source>
        <translation>Elérhető Windows illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="672"/>
        <source>Remove Driver</source>
        <translation>Illesztőprogram eltávolítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Add Driver</source>
        <translation>Illesztőprogram hozzáadása</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="724"/>
        <source>About NDISwrapper</source>
        <translation>Az NDISwrapperről</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="736"/>
        <source>Install NDISwrapper</source>
        <translation>NDISwrapper telepítése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="747"/>
        <source>In order to use Windows drivers you need first to install NDISwrapper</source>
        <translation>A Windows illesztőprogramok használatához telepítenie kell az NDISwrappert</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Uninstall NDISwrapper</source>
        <translation>NDISwrapper eltávolítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="795"/>
        <source>Net diagnostics</source>
        <translation>Hálózat diagnosztika</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="807"/>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="813"/>
        <location filename="../mainwindow.ui" line="933"/>
        <source>Target URL:</source>
        <translation>Cél URL:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <source>Packets</source>
        <translation>Csomagok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="868"/>
        <location filename="../mainwindow.ui" line="991"/>
        <source>Start</source>
        <translation>Indítás</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="885"/>
        <location filename="../mainwindow.ui" line="1008"/>
        <source>Clear</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="899"/>
        <location filename="../mainwindow.ui" line="1022"/>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="927"/>
        <source>Traceroute</source>
        <translation>Traceroute</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="943"/>
        <source>Hops</source>
        <translation>Csomópontok</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="87"/>
        <source>IP address from router:</source>
        <translation>IP-cím az útválasztóról:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="88"/>
        <source>External IP address:</source>
        <translation>Külső IP cím:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="125"/>
        <location filename="../mainwindow.cpp" line="138"/>
        <source>Interface: %1</source>
        <translation>Interfész: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="125"/>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>Driver: %1</source>
        <translation>Illesztőprogram: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="126"/>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Description: %1</source>
        <translation>Leírás: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <location filename="../mainwindow.cpp" line="141"/>
        <source>Product: %1</source>
        <translation>Termék: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Vendor: %1</source>
        <translation>Gyártó: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="128"/>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>Enabled: %1</source>
        <translation>Engedélyezve: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="196"/>
        <location filename="../mainwindow.cpp" line="210"/>
        <location filename="../mainwindow.cpp" line="224"/>
        <source>&amp;Copy</source>
        <translation>&amp;Másolás</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="198"/>
        <location filename="../mainwindow.cpp" line="212"/>
        <location filename="../mainwindow.cpp" line="226"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <location filename="../mainwindow.cpp" line="213"/>
        <location filename="../mainwindow.cpp" line="227"/>
        <source>Copy &amp;All</source>
        <translation>Összes másolás&amp;a</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="201"/>
        <location filename="../mainwindow.cpp" line="215"/>
        <location filename="../mainwindow.cpp" line="229"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <location filename="../mainwindow.cpp" line="278"/>
        <source>Traceroute not installed</source>
        <translation>A traceroute nincs telepítve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Traceroute is not installed, do you want to install it now?</source>
        <translation>A traceroute nincs telepítve. Kívánja most telepíteni?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="268"/>
        <source>Traceroute hasn&apos;t been installed</source>
        <translation>A traceroute nem került telepítésre</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="269"/>
        <source>Traceroute cannot be installed. This may mean you are using the LiveCD or you are unable to reach the software repository,</source>
        <translation>A traceroute nem telepíthető. Ezt okozhatja az, hogy LiveCD-t használ, vagy hogy nem érhetők el a csomagforrások.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="279"/>
        <source>Traceroute is not installed and no Internet connection could be detected so it cannot be installed</source>
        <translation>A traceroute nincs telepítve és nincs internetkapcsolat tehát nem is telepíthető</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>No destination host</source>
        <translation>Nincs cél gép</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>Please fill in the destination host field</source>
        <translation>Töltse ki a cél gép mezőt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="446"/>
        <source>Loaded Drivers</source>
        <translation>Betöltött illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="455"/>
        <source>Unloaded Drivers</source>
        <translation>Nem betöltött illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>Blocked Drivers</source>
        <translation>Tiltólistán lévő illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="489"/>
        <source>Blocked Broadcom Drivers</source>
        <translation>Tiltólistán lévő Broadcom illesztőprogramok</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="511"/>
        <source>Ndiswrapper is not installed</source>
        <translation>Az NDISwrapper nincs telepítve.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="524"/>
        <source>driver installed</source>
        <translation>illesztőprogram telepítve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <source> and in use by </source>
        <translation>és használja:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="540"/>
        <source>. Alternate driver: </source>
        <translation>. Másik illesztőprogram:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Driver removed from blocklist</source>
        <translation>Illesztőprogram eltávolítva a tiltólistáról</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Driver removed from blocklist.</source>
        <translation>Illesztőprogram eltávolítva a tiltólistáról.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="610"/>
        <source>Module blocked</source>
        <translation>Modul tiltólistán</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="762"/>
        <source>Installation successful</source>
        <translation>A telepítés sikeres volt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="764"/>
        <source>Error detected, could not compile ndiswrapper driver.</source>
        <translation>Hiba történt, nem sikerült az ndiswrapper illesztőprogram lefordítása.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="767"/>
        <source>Error detected, could not install ndiswrapper.</source>
        <translation>Hiba történt, nem sikerült az ndiswrapper telepítése.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="779"/>
        <source>Error encountered while removing Ndiswrapper</source>
        <translation>Hiba történt az ndiswrapper eltávolítása közben.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="829"/>
        <source>Unblock Driver</source>
        <translation>Illesztőprogram mégse legyen letiltva</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="861"/>
        <source>enabled</source>
        <translation>engedélyezve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="864"/>
        <source>disabled</source>
        <translation>letiltva</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="867"/>
        <source>WiFi hardware switch is off</source>
        <translation>A WiFi hardver eszköz kapcsolója ki van kapcsolva</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>Locate the Windows driver you want to add</source>
        <translation>Keresse meg a Windows illesztőprogramot, amit hozzá szeretne adni</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="875"/>
        <source>Windows installation information file (*.inf)</source>
        <translation>Windows telepítési információ fájl (*.inf)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="906"/>
        <source>*.sys file no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="918"/>
        <source>sys file refeot found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*.sys file not found</source>
        <translation type="vanished">*.sys fájl nem található</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="907"/>
        <source>The *.sys files must be in the same location as the *.inf file. %1 cannot be found</source>
        <translation>A *.sys fájloknak ugyanabban a mappában kell lennie, mint a *.inf fájl. %1 nem található.</translation>
    </message>
    <message>
        <source>sys file reference not found</source>
        <translation type="vanished">sys fájl hivatkozás nem található</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="919"/>
        <source>The sys file for the given driver cannot be determined after parsing the inf file</source>
        <translation>Nem határozható meg az illesztőprogramhoz tartozó sys fájl, az inf fájl értelmezése alapján</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="936"/>
        <source>Ndiswrapper driver removed.</source>
        <translation>Ndiswrapper illesztőprogram eltávolítva.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="944"/>
        <source>%1 Help</source>
        <translation>%1 Súgó</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="956"/>
        <source>Could not unlock devices.
WiFi device(s) might already be unlocked.</source>
        <translation>Nem sikerült az eszközök feloldása.
A WiFi eszközök esetleg már fel vannak oldva.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="958"/>
        <source>WiFi devices unlocked.</source>
        <translation>WiFi eszközök feloldva.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="973"/>
        <source>About %1</source>
        <translation>%1 névjegye</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="974"/>
        <source>Version: </source>
        <translation>Verzió:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="976"/>
        <source>Program for troubleshooting and configuring network for MX Linux</source>
        <translation>Hálózati problémák és beállítások kezelésére szolgáló program MX Linuxhoz</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="978"/>
        <source>Copyright (c) MEPIS LLC and MX Linux</source>
        <translation>Copyright (c) MEPIS LLC és MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="979"/>
        <source>%1 License</source>
        <translation>%1 licenc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1005"/>
        <source>Driver loaded successfully</source>
        <translation>Illesztőprogram sikeresen betöltve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1020"/>
        <source>Driver unloaded successfully</source>
        <translation>Illesztőprogram sikeresen kilőve</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>License</source>
        <translation>Licenc</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation>Változások listája</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="75"/>
        <source>&amp;Close</source>
        <translation>&amp;Bezár</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="71"/>
        <location filename="../main.cpp" line="79"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="72"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Úgy tűnik, hogy root felhasználóként van bejelentkezve. Jelentkezzen ki és jelentkezzen be egyszerű felhasználóként a program használatához.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="625"/>
        <source>Could not load </source>
        <translation>Betöltés nem sikerült</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>Could not unload </source>
        <translation>Kilövés nem sikerült</translation>
    </message>
</context>
</TS>
